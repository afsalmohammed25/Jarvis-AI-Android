package com.example.jarvisai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 10;
    private static final int REQ_AUDIO = 11;
    private TextView status, conversation;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean malayalam = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(3, 10, 28));
        getWindow().setNavigationBarColor(Color.rgb(3, 10, 28));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(3, 10, 28));

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S");
        title.setTextColor(Color.rgb(0, 220, 255));
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 72));

        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL AI ASSISTANT  •  ANDROID");
        subtitle.setTextColor(Color.rgb(120, 190, 220));
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("SYSTEM READY");
        status.setTextColor(Color.rgb(0, 255, 180));
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 24, 0, 18);
        root.addView(status);

        Button listen = new Button(this);
        listen.setText("🎙  TAP TO TALK");
        listen.setTextSize(16);
        listen.setTextColor(Color.WHITE);
        listen.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 110, 190)));
        root.addView(listen, new LinearLayout.LayoutParams(-1, 58));

        Button language = new Button(this);
        language.setText("Language: English / Malayalam");
        root.addView(language, new LinearLayout.LayoutParams(-1, 52));

        ScrollView scroll = new ScrollView(this);
        conversation = new TextView(this);
        conversation.setTextColor(Color.WHITE);
        conversation.setTextSize(16);
        conversation.setPadding(12, 18, 12, 18);
        conversation.setText("JARVIS: Hello! I am ready.\nജാർവിസ്: നമസ്കാരം! ഞാൻ തയ്യാറാണ്.\n\nTry: time, date, open YouTube, open settings.");
        scroll.addView(conversation);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin = 18;
        root.addView(scroll, sp);

        setContentView(root);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                ttsReady = true;
                setVoiceLanguage();
            }
        });

        listen.setOnClickListener(v -> startListening());
        language.setOnClickListener(v -> {
            malayalam = !malayalam;
            language.setText(malayalam ? "Language: Malayalam" : "Language: English");
            setVoiceLanguage();
            speak(malayalam ? "നമസ്കാരം. ഞാൻ തയ്യാറാണ്." : "Hello. I am ready.");
        });
        append("JARVIS", "Tap the microphone button to speak.");
    }

    private void setVoiceLanguage() {
        if (!ttsReady) return;
        int result = tts.setLanguage(malayalam ? new Locale("ml", "IN") : new Locale("en", "IN"));
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.US);
        }
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, malayalam ? "ml-IN" : "en-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, malayalam ? "ജാർവിസിനോട് സംസാരിക്കുക" : "Speak to JARVIS");
        try {
            status.setText("LISTENING...");
            startActivityForResult(intent, REQ_SPEECH);
        } catch (Exception e) {
            status.setText("Speech recognition unavailable");
            append("JARVIS", "Speech recognition service is not available on this phone.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) handleCommand(results.get(0));
        }
        status.setText("SYSTEM READY");
    }

    private void handleCommand(String raw) {
        String q = raw.toLowerCase(Locale.ROOT);
        append("YOU", raw);
        if (q.contains("time") || q.contains("സമയം")) {
            reply(new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()));
        } else if (q.contains("date") || q.contains("today") || q.contains("തീയതി")) {
            reply(new SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(new Date()));
        } else if (q.contains("youtube")) {
            openApp("com.google.android.youtube", "YouTube");
        } else if (q.contains("settings") || q.contains("ക്രമീകരണം")) {
            startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            reply(malayalam ? "ക്രമീകരണങ്ങൾ തുറക്കുന്നു." : "Opening Settings.");
        } else if (q.contains("hello") || q.contains("ഹലോ") || q.contains("നമസ്കാരം")) {
            reply(malayalam ? "നമസ്കാരം! എനിക്ക് എന്ത് ചെയ്യാൻ കഴിയും?" : "Hello! How can I help you?");
        } else {
            reply(malayalam
                ? "ഈ command ഇപ്പോൾ എനിക്ക് അറിയില്ല. കൂടുതൽ സൗകര്യങ്ങൾ അടുത്ത പതിപ്പിൽ ചേർക്കാം."
                : "I do not know that command yet. More features can be added in the next version.");
        }
    }

    private void openApp(String packageName, String label) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) {
            startActivity(launch);
            reply("Opening " + label + ".");
        } else {
            reply(label + " is not installed.");
        }
    }

    private void reply(String message) {
        append("JARVIS", message);
        speak(message);
    }

    private void speak(String message) {
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
    }

    private void append(String who, String message) {
        conversation.append("\n\n" + who + ": " + message);
    }

    @Override protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
